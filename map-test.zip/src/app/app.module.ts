import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IntensityMapComponent } from './intensity-map/intensity-map.component';
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule
import { FusionChartsModule } from 'angular-fusioncharts';
import * as FusionCharts from 'fusioncharts';
import * as Europe from 'fusionmaps/maps/fusioncharts.europe';
import Maps from 'fusioncharts/fusioncharts.maps'
// Include the specific chart type you want to use
import * as Charts from 'fusioncharts/fusioncharts.charts';

// Include the FusionCharts core module
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';

// Add FusionCharts and FusionTheme modules
FusionChartsModule.fcRoot(FusionCharts, Maps, Europe);

@NgModule({
  declarations: [
    AppComponent,
    IntensityMapComponent
  ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FusionChartsModule,
      HttpClientModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
