import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShipmentDataService {
  private shipmentDataUrl = 'assets/shipping-data.json'; // Adjust the URL accordingly

  constructor(private http: HttpClient) { }

  getShipmentData(): Observable<any> {
    return this.http.get(this.shipmentDataUrl);
  }

  calculateIntensity(data: any[] | undefined, item:any): number {
    // @ts-ignore
    const maxShipmentFrequency = data.filter((s) => s.pickupCountry === item.pickupCountry).length;

    // @ts-ignore
    const intensity = maxShipmentFrequency/data.length


    return intensity;
  }
}
