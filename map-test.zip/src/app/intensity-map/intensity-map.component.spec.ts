import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IntensityMapComponent } from './intensity-map.component';

describe('IntensityMapComponent', () => {
  let component: IntensityMapComponent;
  let fixture: ComponentFixture<IntensityMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IntensityMapComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IntensityMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
