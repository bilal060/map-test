import { Component, OnInit } from '@angular/core';
import { ShipmentDataService } from '../shipment-data.service';
import {countriesData} from 'src/assets/countries.Data';

@Component({
  selector: 'app-intensity-map',
  templateUrl: './intensity-map.component.html',
})

export class IntensityMapComponent implements OnInit {
  mapOptions: any;
  shipmentData: any[] = [];
  width = '1200';
  height = '800';
  type = 'europe'; // Adjust the map type based on your needs
  dataFormat = 'json';

  dataSource: any = {
    chart: {
      caption: 'Average Temperature of European Countries',
      subcaption: '1979 - 2000',
      entityfillhovercolor: '#f60213',
      numbersuffix: 'intensity',
      showlabels: '1',
      borderthickness: '1' ,
      theme: 'Carbon',
      entitytooltext:
        '<b>$lname</b> has an intensity: <b>$value</b>',
    },
    colorrange: {
      minvalue: '0.0',
      code: '#00A971',
      gradient: '1',
      color: [
        {
          minvalue: '0.0',
          maxvalue: '0.3',
          code: '#880e3d',
        },
        {
          minvalue: '0.30',
          maxvalue: '0.6',
          code: '#FD8963',
        },
        {
          minvalue: '0.6',
          maxvalue: '1',
          code: '#D60100',
        },
      ],
    },
    data: [],
  };

  constructor(private shipmentService: ShipmentDataService) {}

  ngOnInit(): void {
    this.loadShipmentData();
  }

  loadShipmentData(): void {
    this.shipmentService.getShipmentData().subscribe((data) => {
      this.shipmentData = data;
      let results: { id: string; pickupLocation: string; pickupPostcode: string; value: any; }[] = []

      this.shipmentData.forEach((item: {pickupPostcode: any; pickupLocation: any; pickupCountry:any ; frequency: number; pickupLatlong: { coordinates: number[]; }; pickupCity: any; }) => {
        const intensity = this.shipmentService.calculateIntensity(this.shipmentData, item).toFixed(2);
        const [countryCode] = countriesData.filter((s) => s.Label === item.pickupCountry);
        if (countryCode) {

          // Check if the ID already exists in the results array
          const existingResult = results.find((r) => r.id === countryCode.ID);
          if (!existingResult) {

            results.push({
              id: countryCode.ID,
              value: parseFloat(intensity),
              pickupLocation: item.pickupLocation,
              pickupPostcode: item.pickupPostcode,
            });
          }
        }

        let valueExist = results.filter(f => f.id === countryCode.ID).length > 0;

        if(!valueExist) {

          results.push({
            id: countryCode.ID,
            value: intensity,
            pickupLocation: item.pickupLocation,
            pickupPostcode:item.pickupPostcode
          })
        }
      });

      this.dataSource.data = results
      this.initializeMap();
    });
  }

  initializeMap(): void {
    this.mapOptions = {
    };
  }
}
